#include <math.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>

 main(argc,argv)
  int argc;
  char **argv;
 {
 char filename[250],outputfile[250],inputfile[250],input_s[300];
 FILE *fp0,*fp1,*fp2,*fp3,*fp4,*fp5,*fp6;
 float time_s,hf_s,rad1,temp1,temp2,temp3,temp4,timea[10001],qt[10001],qb[10001];
 float dt,temp5,viscosity,rr[200],tt[200],visc[200];
 int nz,i,ip,j,nstep,compute_node,nno,jz;


  viscosity=3300*9.8*(3e-5)*2500*6.37*6.37*6.37*1e18/(2e8*1e-6);
  printf("visc=%g\n",viscosity);

  nno = 65*65;
  nz = 49;
  
  sprintf(filename,"%s.dispmap",argv[1]);
  fp6=fopen(filename,"w");
  sprintf(filename,"%s.tdispmap",argv[1]);
  fp2=fopen(filename,"w");
  sprintf(filename,"%s.viscmap",argv[1]);
  fp4=fopen(filename,"w");
  sprintf(filename,"%s.stressmap",argv[1]);
  fp5=fopen(filename,"w");

  nstep=atoi(argv[2]);
  compute_node=atoi(argv[3]);
  jz=atoi(argv[4]);

  if (nstep<450)
    dt=90000/450;
  else if (nstep<525)
    dt=15000/(525-450);
  else if (nstep<1185)
    dt=16500/(1185-525);
  else if (nstep<1201)
    dt=400/(1201-1185);
  else if (nstep<=1205)
    dt=100/(1205-1201);

  for (ip=1;ip<=12;ip++)  {

    sprintf(filename,"%s.coord_s.%d",argv[1],ip-1);
    fprintf(stderr,"%s\n",filename);
    fp0=fopen(filename,"r");
    fgets(input_s,300,fp0);
    sprintf(filename,"/scratch_node%02d/szhong/tmpdata/%s.topo_s.%d.%d",ip+compute_node-1,argv[1],ip-1,nstep);
    fprintf(stderr,"%s\n",filename);
    fp1=fopen(filename,"r");
    fgets(input_s,300,fp1);
    sprintf(filename,"/scratch_node%02d/szhong/tmpdata/%s.visc_str.%d.%d",ip+compute_node-1,argv[1],ip-1,nstep);
    fprintf(stderr,"%s\n",filename);
    fp3=fopen(filename,"r");
    fgets(input_s,300,fp3);

    rad1 = 180.0/M_PI;

    for (i=1;i<=nno;i++) {
       fgets(input_s,300,fp0);
       sscanf(input_s,"%f %f",&temp1,&temp2);
       fgets(input_s,300,fp1);
       sscanf(input_s,"%f %f %f %f %f %f %f",&temp4,&temp3,&temp3,&temp3,&temp5,&temp3,&temp3);
       temp1=90-temp1*rad1;
       temp2=temp2*rad1;
       temp4 = temp4*6370000*1000;
       temp5 = temp5*6370000*1000*1000/dt;  // mm/yr
       fprintf(fp2,"%g %g %g\n",temp2,temp1,temp4); 
       fprintf(fp6,"%g %g %g\n",temp2,temp1,temp5); 
       for (j=1;j<=nz;j++) {
          fgets(input_s,300,fp3);
          sscanf(input_s,"%f %f",&temp3,&temp4);
          if (j==jz) {
            fprintf(fp4,"%g %g %g\n",temp2,temp1,log10f(temp3)); 
            fprintf(fp5,"%g %g %g\n",temp2,temp1,log10f(temp4*1.43e11*1e3)); 
            }
          }

       }
    fclose(fp0);
    fclose(fp1);
    fclose(fp3);
    }

  fclose(fp2);
  fclose(fp4);
  fclose(fp5);
  fclose(fp6);

//  while (fgets(input_s,300,fp0)!=NULL)  {
  

 }
