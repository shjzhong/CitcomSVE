#include <math.h>/*read in 4 parameters, CASEBM a nondimensionaltime1(bigger) nondimentionaltime2*/
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
//#include <syslib.h>
//ifndef __
//#include <strings.h>
//#else
#include <string.h>
#include <ctype.h>
//#endif

 main(argc,argv)
  int argc;
  char **argv;
 {

 FILE *fp0,*fp1,*fp2,*fp3,*fp4,*fp5;
 char input_s0[200],input_s1[200],input_s2[200],filename0[250],filename1[250],filename2[250],filename3[250],nonechar[200];
 char suffix[100];
 float *time_non,*Tglobal,*Vrms,*heattop,*heatbottom,*Tmin,*Tmax,*Vmin,*Vmax;
 float *time_non_in,*Tglobal_in,*Vrms_in,*heattop_in,*heatbottom_in,*Tmin_in,*Tmax_in,*Vmin_in,*Vmax_in;
 int nprocz,a,b,j,k,m,n,h,i,ntot,length,ic;
 float temp1,temp2,temp3top,temp3bottom,temp3,temp4,temp5,temp6,temp7,temp8,nonef;
 float integr_Tglobal,integr_Vrms,integr_heattop,integr_heatbottom,integr_Tmin,integr_Tmax,integr_Vmin,integr_Vmax;
 float aver_Tglobal,aver_Vrms,aver_heattop,aver_heatbottom,aver_Tmin,aver_Tmax,aver_Vmin,aver_Vmax;
 float variation_Tglobal,variation_Vrms,variation_heattop,variation_heatbottom,variation_Tmin,variation_Tmax,variation_Vmin,variation_Vmax;
 float thegma_Tglobal,thegma_Vrms,thegma_heattop,thegma_heatbottom,thegma_Tmin,thegma_Tmax,thegma_Vmin,thegma_Vmax;
 float time1,time2,ave1,ave2,ave3,ave4;
 float depth,scaling_length,scaling_potential,scaling_heatbottom,scaling_time;
 float force1[90],force2[90],force3[90],tot[4][9],resi[4][9];

  scaling_time = 2.0e21/(1.4305e11*3.15576e7);
  scaling_length = 6370000;
  scaling_potential = 4.0*M_PI*6.6742e-11*4604.4*scaling_length*scaling_length;

  ntot = atoi(argv[2]);

  ic = atoi(argv[3]);

  sprintf(filename0,"%s.bm_%d_l1",argv[1],ic);
  fp2 = fopen(filename0,"w");
  sprintf(filename0,"%s.bm_%d_l2",argv[1],ic);
  fp3 = fopen(filename0,"w");
  sprintf(filename0,"%s.bm_%d_l4",argv[1],ic);
  fp4 = fopen(filename0,"w");
  sprintf(filename0,"%s.bm_%d_l8",argv[1],ic);
  fp5 = fopen(filename0,"w");

fprintf(stderr,"%d\n",ntot);

  for (i=2;i<=ntot;i=i+2)  {
    sprintf(filename0,"%s.tps_sharm.%d",argv[1],i);
fprintf(stderr,"%s\n",filename0);
    fp0 = fopen(filename0,"r");
    fgets(input_s0,200,fp0);
    sscanf(input_s0,"%d %g",&m,&time1);
    fgets(input_s0,200,fp0);
    time1 = time1*scaling_time;

    sprintf(filename0,"%s.pttl_sharm.%d",argv[1],i);
    fp1 = fopen(filename0,"r");
    fgets(input_s0,200,fp1);
    fgets(input_s0,200,fp1);

    for (n=0;n<=8;n++)  {    
      force1[n] = 0;
      force2[n] = 0;
      force3[n] = 0;
      for (m=0;m<=n;m++)  {    
        fgets(input_s0,200,fp0);
        sscanf(input_s0,"%d %d %g %g",&j,&j,&temp1,&temp2);
        fgets(input_s0,200,fp1);
        sscanf(input_s0,"%d %d %g %g",&j,&j,&temp3,&temp4);
        if (m>0) {
           temp1 = temp1/sqrt(2.0);
           temp2 = temp2/sqrt(2.0);
           temp3 = temp3/sqrt(2.0);
           temp4 = temp4/sqrt(2.0);
           }
        temp1 = scaling_length*temp1;
        temp2 = scaling_length*temp2;
        temp3 = scaling_potential*temp3/9.8;
        temp4 = scaling_potential*temp4/9.8;
        temp5 = temp1 - temp3;
        temp6 = temp2 - temp4;
        force1[n] += temp1*temp1 + temp2*temp2;
        force2[n] += temp3*temp3 + temp4*temp4;
        force3[n] += temp5*temp5 + temp6*temp6;
        }
      force1[n] = sqrt(force1[n]/(n+1.0));
      force2[n] = sqrt(force2[n]/(n+1.0));
      force3[n] = sqrt(force3[n]/(n+1.0));
      }
    fclose(fp0);
    fclose(fp1);

   if (ic==1)  {    // topo
    fprintf(fp2,"%.4e %.4e\n",time1,force1[1]);
    fprintf(fp3,"%.4e %.4e\n",time1,force1[2]);
    fprintf(fp4,"%.4e %.4e\n",time1,force1[4]);
    fprintf(fp5,"%.4e %.4e\n",time1,force1[8]);
    }
   else if (ic==2)  {   // geoid
    fprintf(fp2,"%.4e %.4e\n",time1,force2[1]);
    fprintf(fp3,"%.4e %.4e\n",time1,force2[2]);
    fprintf(fp4,"%.4e %.4e\n",time1,force2[4]);
    fprintf(fp5,"%.4e %.4e\n",time1,force2[8]);
    }
   else if (ic==3)  {   // rsl 
    fprintf(fp2,"%.4e %.4e\n",time1,force3[1]);
    fprintf(fp3,"%.4e %.4e\n",time1,force3[2]);
    fprintf(fp4,"%.4e %.4e\n",time1,force3[4]);
    fprintf(fp5,"%.4e %.4e\n",time1,force3[8]);
    }

  }
    fclose(fp2);
    fclose(fp3);
    fclose(fp4);
    fclose(fp5);
  
 }


  float average(f,time,m)
  float *f,*time;
  int m;
{
  float aver,tt;
  int i;

  aver=tt=0.0;
  
  for (i=1;i<m;i++)   {
    aver+=0.5*(f[i+1]+f[i])*(time[i+1]-time[i]);
    tt+=(time[i+1]-time[i]);
  }
  aver = aver/tt;

  return (aver);
}

  float std_dev(f,time,m,aver)
  float *f,*time,aver;
  int m;
{
  float std,tt;
  int i;

  std=tt=0.0;
  
  for (i=1;i<m;i++)   {
    std+=0.5*((f[i+1]-aver)*(f[i+1]-aver)+(f[i]-aver)*(f[i]-aver))
	    *(time[i+1]-time[i]);
    tt+=(time[i+1]-time[i]);
  }
  std = sqrt(std/tt);
  return (std);
}
