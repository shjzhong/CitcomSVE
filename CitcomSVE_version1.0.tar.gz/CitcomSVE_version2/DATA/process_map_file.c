#include <math.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>

 main(argc,argv)
  int argc;
  char **argv;
 {
 char filename[250],outputfile[250],inputfile[250],input_s[300];
 FILE *fp0,*fp1,*fp2,*fp3;
 float time_s,hf_s,rad1,temp1,temp2,temp3,temp4,temp5,temp6,timea[10001],qt[10001],qb[10001];
 float scale_length,scale_potential,viscosity,rr[200],tt[200],visc[200];

 int nproc,i,ip,ipp,j,nstep,compute_node,nno,nox,noy;

 scale_length = 6370000;
 scale_potential = 4.0*M_PI*6.6742e-11*4604.4*scale_length*scale_length;
 
  nproc = 48;    // number of the processes for the surface
  nox = noy = 41; 
  nno = nox*noy;
  
  nstep=atoi(argv[2]);

  sprintf(filename,"%s.map_disp.%d",argv[1],nstep);
  fp2=fopen(filename,"w");
  sprintf(filename,"%s.map_geoid.%d",argv[1],nstep);
  fp3=fopen(filename,"w");

  for (ipp=1;ipp<=nproc;ipp++)  {
    ip = ipp;
    sprintf(filename,"%s.coord_s.%d",argv[1],ip-1);
    fprintf(stderr,"%s\n",filename);
    fp0=fopen(filename,"r");
    fgets(input_s,300,fp0);
//    sprintf(filename,"/scratch_node%02d/szhong/tmpdata/%s.topo_s.%d.%d",ip,argv[1],ip-1,nstep);
    sprintf(filename,"%s.topo_s.%d.%d",argv[1],ip-1,nstep);
    fprintf(stderr,"%s\n",filename);
    fp1=fopen(filename,"r");
    fgets(input_s,300,fp1);

    rad1 = 180.0/M_PI;

    for (i=1;i<=nno;i++) {
       fgets(input_s,300,fp0);
       sscanf(input_s,"%f %f",&temp1,&temp2);
       fgets(input_s,300,fp1);
       sscanf(input_s,"%f %f %f %f",&temp3,&temp4,&temp5,&temp6);
       temp1=90-temp1*rad1;
       temp2=temp2*rad1;
       temp3 = temp3*scale_length;     // turn to meters
       temp5 = temp5*scale_potential/9.8;     // turn to meters
       fprintf(fp2,"%g %g %g\n",temp2,temp1,temp3); 
       fprintf(fp3,"%g %g %g\n",temp2,temp1,temp5); 
       }
    fclose(fp0);
    fclose(fp1);
    }

  fclose(fp2);
  fclose(fp3);

 }
