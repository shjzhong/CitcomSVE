/* -------------------------------------------------------------------------
  This version of CitcomSVE code is built from CIG version of CitcomS 3.1.
  CitcomSVE solves viscoelastic response of a planetary mantle to surface loads
  or tidal potential load. The original version of CitcomSVE had been built 
  from 2002 to 2013 out of the original version of CitcomS predated CIG by 
  Shijie Zhong, Archie Paulson, Geruo A, and John Wahr (Zhong et al., 2003; 
  Paulson et al., 2005; A et al., 2013). The current version was built to make
  the use of improved domain decomposition of CIG version of CitcomS, which 
  enables parallel computing on a much larger scale than the original version
  of CitcomSVE. The rebuilding and migration of the code started in the fall 
  of 2019, but the main work including full benchmarks was largely carried out
  in 2020 as we were trapped at home by the Pandemic.
                                              Shijie Zhong
                                             December 2, 2020
 -------------------------------------------------------------------------- */
#include "global_defs.h"
#include "element_definitions.h"
#include "parsing.h"
#include <math.h>
#include <sys/types.h>

#include <stdio.h>

/* ========================================================================== 
 * set_free_surfaces(E)
 * Called only once in read_instructions (in Instructions.c)
 * ========================================================================== */
void set_free_surfaces(E)
    struct All_variables *E;
{

    void parallel_process_termination();
    void  get_surface_loads();
    int lev,i,node1,node2,m;

    /* mark the vertical d.o.f. for nodes on density boundaries */

    if (E->parallel.me_loc[3] == 0)                      { 
        for (lev=E->mesh.gridmax;lev>=E->mesh.gridmin;lev--)
        for (m=1;m<=E->sphere.caps_per_proc;m++)  
        for (i=1;i<=E->lmesh.NEL[lev];i++)    
        if ((i-1)%E->lmesh.ELZ[lev]==0)   {
            E->ELEMENT[lev][m][i] = E->ELEMENT[lev][m][i] | BOUNDARIES;
            E->ELEMENT[lev][m][i] = E->ELEMENT[lev][m][i] | BOUNDARY2;    /*CMB*/
            E->NODE[lev][m][E->IEN[lev][m][i].node[1]] = E->NODE[lev][m][E->IEN[lev][m][i].node[1]] | RESTORE;    /*CMB*/
            E->NODE[lev][m][E->IEN[lev][m][i].node[2]] = E->NODE[lev][m][E->IEN[lev][m][i].node[2]] | RESTORE;    /*CMB*/
            E->NODE[lev][m][E->IEN[lev][m][i].node[3]] = E->NODE[lev][m][E->IEN[lev][m][i].node[3]] | RESTORE;    /*CMB*/
            E->NODE[lev][m][E->IEN[lev][m][i].node[4]] = E->NODE[lev][m][E->IEN[lev][m][i].node[4]] | RESTORE;    /*CMB*/
        }
    }
    if (E->parallel.me_loc[3] == E->parallel.nprocz-1)   {
        for (lev=E->mesh.gridmax;lev>=E->mesh.gridmin;lev--)
        for (m=1;m<=E->sphere.caps_per_proc;m++)  
        for (i=1;i<=E->lmesh.NEL[lev];i++)    
        if (i%E->lmesh.ELZ[lev]==0)   {
            E->ELEMENT[lev][m][i] = E->ELEMENT[lev][m][i] | BOUNDARIES;
            E->ELEMENT[lev][m][i] = E->ELEMENT[lev][m][i] | BOUNDARY1;    /*Surface*/
            E->NODE[lev][m][E->IEN[lev][m][i].node[5]] = E->NODE[lev][m][E->IEN[lev][m][i].node[5]] | RESTORE;
            E->NODE[lev][m][E->IEN[lev][m][i].node[6]] = E->NODE[lev][m][E->IEN[lev][m][i].node[6]] | RESTORE;
            E->NODE[lev][m][E->IEN[lev][m][i].node[7]] = E->NODE[lev][m][E->IEN[lev][m][i].node[7]] | RESTORE;
            E->NODE[lev][m][E->IEN[lev][m][i].node[8]] = E->NODE[lev][m][E->IEN[lev][m][i].node[8]] | RESTORE;
        }
    }

    /* get the initial rho*g*h for nodes on density boundaries */

    // get the load (single harmonic, ice3G, or ice caps):
    get_surface_loads(E);

    return;
}


/* ======================================================= 
  before assembling a force vector, determine topography
  at each density interface and convert it into stress 
  drho*g*h
 =======================================================  */

void get_boundary_forces(E,count) 
    struct All_variables *E;
    int count;
{
    int m,ll,mm,i,j,p;
    double density_cmb,density_surf,total, length;
    double modified_plgndr_a(),con,t1;
    void remove_average();
    void parallel_process_termination();
    double total_surface_integral();
    double *TG[4],temp1,temp2;

    void load_to_CM();
    void load_to_CM_grav();

    density_surf = 1.0;
    density_cmb = (E->data.density_below-E->data.density)/E->data.density;

        /* If this is the second (or later) self-gravity iteration for this
         * timestep, put the deformation from the previous iteration into
         * slice.surf/botm[2], then zero the CM for these loads (these loads
         * will be used in calculate_potential).
         * Then add them to the initial slice.load[0/2] to get the loads for 
         * this timestep, slice.load[1/3] (although I believe these are just
         * over-written before they're used).      */

    if (count==0)   {   
        /* slice.load[0] and slice.load[2] are the surf/cmb loads
         * from the end of the previous timestep, so return. */
      return;
      }
    else if (count)   {
        // surface:
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)   {
            for (m=1;m<=E->sphere.caps_per_proc;m++)
            for (j=1;j<=E->lmesh.nsf;j++)    {
                i = j*E->lmesh.noz;
                E->slice_ve.surf[2][m][j] = E->U[m][E->id[m][i].doff[3]]
                                               * E->ve_data_cont.surf_scaling
                                        + E->slice_ve.dynamic_oceanload[m][j];
            }
            remove_average(E,E->slice_ve.surf[2],1);
        }
        // cmb:
        if (E->parallel.me_loc[3]==0)   {
            for (m=1;m<=E->sphere.caps_per_proc;m++)
            for (j=1;j<=E->lmesh.nsf;j++)    {
                i = (j-1)*E->lmesh.noz + 1;
                E->slice_ve.botm[2][m][j] = E->U[m][E->id[m][i].doff[3]];
                E->slice_ve.botm[2][m][j] *= E->ve_data_cont.botm_scaling;
            }
            remove_average(E,E->slice_ve.botm[2],0);
        }

        load_to_CM_grav( E, E->slice_ve.surf[2], E->slice_ve.botm[2], 0 );

    }

    return;
}



/* ======================================================= 
   for each element el on boundaries, determine contributions
   from topographic deflection to elt_f
 =======================================================  */

void load_boundary_forces(E,el,elt_f,m)
    struct All_variables *E;
    int el,m;
    double elt_f[24];
{

    double temp,x[3][3],force[9],force_at_gs[9];
    int ic,nn[5],e, i, k, p, p2, lnode[5];

    const int lev = E->mesh.levmax;
    const int onedp = onedvpoints[E->mesh.nsd];

    if (E->parallel.me_loc[3]==0 || E->parallel.me_loc[3]==E->parallel.nprocz-1)  {

        if (el%E->lmesh.elz==0 && E->parallel.me_loc[3]==E->parallel.nprocz-1)   {
            e = el/E->lmesh.elz;
            for(k=1;k<=onedvpoints[E->mesh.nsd];k++)   {
                lnode[k] = E->sien[m][e].node[k];
                force[k] = E->slice_ve.load[1][m][ lnode[k] ];
            }
            ic = 1;     /*      top  */
        }
        else if ((el-1)%E->lmesh.elz==0 && E->parallel.me_loc[3]==0)  {
            e = (el-1)/E->lmesh.elz+1;
            for(k=1;k<=onedvpoints[E->mesh.nsd];k++)   {
                lnode[k] = E->sien[m][e].node[k];
                force[k] = E->slice_ve.load[3][m][ lnode[k] ];
            }
            ic = 0;     /*      bottom */
        }
        else {
            return;
        }

        for(k=1;k<=onedvpoints[E->mesh.nsd];k++)   
            nn[k] = k+ic*4;

        for (i=1;i<=onedvpoints[E->mesh.nsd];i++)   {
            force_at_gs[i] = 0.0;
            for(k=1;k<=onedvpoints[E->mesh.nsd];k++)
                force_at_gs[i] += force[k] * E->M.vpt[GMVINDEX(k,i)];
        }

        for(k=1;k<=onedp;k++) {
            for (i=1;i<=onedp;i++)  
                elt_f[3*nn[k]-1] += E->B_R[lev][m][nn[k]][(e-1)*onedp+i] * force_at_gs[i];
            }
    }

    return;
}


/* ========================================================================== 
 * get_surface_loads(E)
 * Called only once in set_free_surfaces (above).
 * Gets the ice load (single harmonic, ice3G, or ice caps).
 * ========================================================================== */
void get_surface_loads(E) 
    struct All_variables *E;
{
    FILE *fp;
    int oldstep,m,ll,mm,p,i,j,n;
    double tau,total, length, stress_scale;
    double dist,distance(),modified_plgndr_a(),con,t1,f1;
    double x1,y1,z1,density_ice,r,t,f,ri,ro,icet,icef,icer,oldampt;
    int m1 = E->parallel.me;

    double itemp[100], temp[100];

    char outfile[255];
    void sphere_expansion_output();
    void remove_average();
    void get_ice3g();  
    void parallel_process_termination();
    void calculate_potential();
    void apply_new_loads(); 

    void get_static_oceanload();
    void load_to_CM() ;
    void load_to_CM_grav() ;


    E->ve_data_cont.potential_scaling = 4.0*M_PI*E->data.grav_const*E->data.density
        *E->sphere.dradius*E->sphere.dradius;
    E->ve_data_cont.rotation_rate = E->ve_data_cont.rotation_rate*2.0*M_PI/(24.0*3600.0);

        E->ve_data_cont.Rsg = 4.0*M_PI*E->data.grav_const*E->data.density
            *E->data.density*E->sphere.dradius*E->sphere.dradius
            /E->ve_data_cont.shear_mod;
        // the following are used to convert nondim height -> nondim stress
        E->ve_data_cont.botm_scaling = (E->data.density_below-E->data.density)
                              *E->data.grav_acc
                              *E->sphere.dradius/E->ve_data_cont.shear_mod;
        E->ve_data_cont.surf_scaling = E->data.density*E->data.grav_acc
                              *E->sphere.dradius /E->ve_data_cont.shear_mod;

    density_ice = 917.4;
    E->ve_data_cont.ice_stress_scale = E->ve_data_cont.surf_scaling*density_ice/E->data.density;

    if (E->parallel.me==0)  {
        fprintf(E->fp,"scale %.5e %.5e %.5e %.5e\n",
                      E->ve_data_cont.botm_scaling,
                      E->ve_data_cont.surf_scaling,
                      E->ve_data_cont.ice_stress_scale,E->ve_data_cont.tau);
        fflush(E->fp); 
    }

// the following three lines are moved to Instructions.c
//    input_int("stages",&(E->ve_data_cont.stages),"1",m1);
//    input_int_vector("step",E->ve_data_cont.stages,(E->ve_data_cont.stages_step),m1);
//    input_double_vector("timestep",E->ve_data_cont.stages,(E->ve_data_cont.stages_time),m1);

    oldstep = 0;
    for (i=0;i<E->ve_data_cont.stages;i++)  {
        if (E->ve_data_cont.Heaviside==1)
            E->ve_data_cont.stages_timestep[i] = E->ve_data_cont.stages_time[i]
                /((E->ve_data_cont.stages_step[i]-oldstep));
        else 
            E->ve_data_cont.stages_timestep[i] = E->ve_data_cont.stages_time[i]
                /(E->ve_data_cont.tau*(E->ve_data_cont.stages_step[i]-oldstep));
        oldstep = E->ve_data_cont.stages_step[i];
    }

    if (E->ve_data_cont.Heaviside==1)   { 
        E->monitor.elapsed_time=0.0;
        E->ve_data_cont.DIRECT=1;
        }
    else  {
        // set the current timstep to 1, and the current elapsed_time to dt:
        E->monitor.elapsed_time=E->ve_data_cont.stages_timestep[0];
        E->advection.timestep=E->ve_data_cont.stages_timestep[0];
        E->monitor.solution_cycles = 1;
        E->ve_data_cont.DIRECT=1;
    }

    // Set the initial loads:
    
    E->ve_data_cont.change_of_load = 1;  // used by apply_new_loads

    if (E->ve_data_cont.Heaviside==1)    {
        /* loading at a single harmonic */
        mm = E->convection.perturb_mm[0];
        ll = E->convection.perturb_ll[0];
        con = E->convection.perturb_mag[0];

        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)    {
            i = j*E->lmesh.noz;
            t1 = E->SX[E->mesh.levmax][m][1][i];
            f1 = E->SX[E->mesh.levmax][m][2][i];
            if (E->ve_data_cont.apply_potential==0)
                E->Xsurf[3][m][j] = con*modified_plgndr_a(ll,mm,t1)*cos(mm*f1);
            else if (E->ve_data_cont.apply_potential==1) { 
                E->Xsurf[3][m][j] = 0.0;
                E->init_potential[0][m][j] = con*E->sphere.ro*E->sphere.ro*modified_plgndr_a(ll,mm,t1)*cos(mm*f1);
                E->init_potential[1][m][j] = con*E->sphere.ri*E->sphere.ri*modified_plgndr_a(ll,mm,t1)*cos(mm*f1);
                }
        }
        remove_average(E,E->Xsurf[3],1);

        sphere_expansion_output(E,1,E->Xsurf[3],
                                E->sphere.sphc[0],E->sphere.sphs[0],
                                E->monitor.solution_cycles,"init_surf");

        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)    {
            E->slice_ve.surf[2][m][j] = E->Xsurf[3][m][j]*E->ve_data_cont.surf_scaling;
            E->slice_ve.botm[2][m][j] = 0.0 ;
        }

        load_to_CM_grav( E, E->slice_ve.surf[2], E->slice_ve.botm[2], 1 );
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)    {
            E->slice_ve.load[0][m][j] = E->slice_ve.surf[2][m][j] ;
            E->slice_ve.load[2][m][j] = E->slice_ve.botm[2][m][j] ;
        }
    }
    else if (E->ve_data_cont.Heaviside==2)  {   /* ice-3g */
        // read 1st epoch of ice3g and (if appropriate) the oceanload:
        get_ice3g(E,E->slice_ve.iceload[0]);  
        if (E->ve_data_cont.SLE) get_static_oceanload(E);

    } // end ice loading

    // Put the initial loads into slice.load[0/2], and set init_potential:
    apply_new_loads(E);

    if (E->ve_data_cont.Heaviside==1)  
        E->ve_data_cont.change_of_load = 0; // no more load changes in this case

    return;
}

/* =============================================================================
 * double distance(x0,y0,z0,t1,f1)
 *    dist = 2.0*arcsin(dist/diameter) = 2.0*arcsin(0.5*dist/radius) 
 * ===========================================================================*/
double distance(x0,y0,z0,t1,f1)
    double x0,y0,z0,t1,f1;
{

    double dist,x2,y2,z2;

    x2 = sin(t1)*cos(f1); 
    y2 = sin(t1)*sin(f1); 
    z2 = cos(t1);
    dist = sqrt( (x2-x0)*(x2-x0) + (y2-y0)*(y2-y0) + (z2-z0)*(z2-z0) );
    dist = 0.5*dist;
    dist = 2.0*asin(dist);
    /* dist = 2.0*arcsin(dist/diameter) = 2.0*arcsin(0.5*dist/radius) */
    return (dist);
}


/* ======================================================= 
  for self-G cases, the relation between stress srr and boundary
  topography needs to add the effects of potential for CMB.
 =======================================================  */
void  append_boundary_forces(E)
    struct All_variables *E;
{
    int m,is,ib,j;
    double con,con1;
    int debug_write_load = 0;
    void sphere_expansion_output();

    if (E->ve_data_cont.SELFG)  {// for conversion of potential -> geoid 
        con1 = E->ve_data_cont.Rsg; // surface
        con =  E->ve_data_cont.Rsg  // CMB
               * (E->data.density_below-E->data.density) / E->data.density;
    }
    else  con = con1 = 0.0 ;

    if (E->parallel.me_loc[3]==E->parallel.nprocz-1)          // surface
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)    {
            E->slice_ve.load[1][m][j] = -(  E->slice_ve.load[0][m][j] 
                                       + E->slice_ve.dynamic_oceanload[m][j] )
                                     + con1*E->potential[0][m][j];
            /* E->slice_ve.load[1][m][j] = -E->slice_ve.load[1][m][j] 
                                     + con1*E->potential[m][is];*/
        }
    if (E->parallel.me_loc[3]==0)                              // CMB
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)    {
            /* the negative sign out of ( ... ) is from the surface
               normal at the bottom is negative or points to the
               -r direction */
            E->slice_ve.load[3][m][j] = - ( E->slice_ve.load[2][m][j] 
                                         - con*E->potential[1][m][j] ) ; 
            /* E->slice_ve.load[3][m][j] = - ( E->slice_ve.load[3][m][j] 
                                        - con*E->potential[m][ib]) ; */
        }

    if (debug_write_load) 
        sphere_expansion_output(E,1,E->slice_ve.load[1],
                                E->sphere.sphc[0],E->sphere.sphs[0],
                                E->monitor.solution_cycles,"surfaceload");

    return;
}


/*==============================================================================
 * calculate_potential (E,X_surf,X_cmb,potential_surf,potential_cmb)
 * =============================================================================
 * Takes the surface masses given in X_surf/cmb, computes their gravitational
 * potential at the surface and CMB, and puts it in potential_surf/cmb. 
 * If E->control.polar_wander is true, it further changes the potential arrays
 * (in spherical harmonic l,m=2,1) to via polar_wander_effects.
 * Notes:
 *     X_surf/cmb must be nondimensional stresses (such as E->iceload).
 *     This routine will not change the values of X_surf and X_cmb.
 *=========================================================================== */
void calculate_potential(E,X_surf,X_cmb,potential_surf,potential_cmb,icon)
    struct All_variables *E;
    double **X_surf;
    double **X_cmb;
    double **potential_surf;
    double **potential_cmb;
    int icon;
{
    int ib,is,m,ll,ll1,ll2,mm,p,i,j,k,n;
    double con,r,t,f,rir,ri,ro,modified_plgndr_a();
    double density_surf,density_cmb;

    static int been=0;
    static double brll1[65],brll2[65];
    static double srll1[65],srll2[65];
    void  sphere_expansion_VE();
    void  polar_wander_effects();
    void  exchange_sphcs();

    ri = E->sphere.ri;
    ro = E->sphere.ro;
    density_surf = 1.0;
    density_cmb = (E->data.density_below-E->data.density)/E->data.density;

    if (been==0)  {
        been = 1;
        rir = 1.0;
        for (ll=1;ll<=E->output.llmax;ll++)    {
            brll1[ll] = pow(ri,(double)(ll))/(2.0*ll+1.0); 
            brll2[ll] = ri*pow(rir,(double)(ll+1))/(2.0*ll+1.0); 
            srll1[ll] = pow(ro,(double)(ll))/(2.0*ll+1.0); 
            srll2[ll] = ri*pow(ri,(double)(ll+1))/(2.0*ll+1.0); 
        }
    }

   for (m=1;m<=E->sphere.caps_per_proc;m++)
   for (j=1;j<=E->lmesh.nsf;j++) {
        potential_surf[m][j] = 0.0; 
        potential_cmb[m][j] = 0.0; 
        E->Xsurf[1][m][j] = 0.0;
        E->Xsurf[2][m][j] = 0.0;
        }

    // Ylm expansion of surface mass:
    if (E->parallel.me_loc[3]==E->parallel.nprocz-1)   {
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            // scale nondim stress -> nondim height of rock
            E->Xsurf[1][m][j] = X_surf[m][j]/E->ve_data_cont.surf_scaling;
        }
        sphere_expansion_VE(E,1,E->Xsurf[1],
                         E->sphere.sphc[0],E->sphere.sphs[0],E->output.llmax);
        for (ll=0;ll<=E->output.llmax;ll++)
        for (mm=0;mm<=ll;mm++)   {
            p = E->sphere.hindex[ll][mm];
            E->sphere.sphc[0][p] *= density_surf;
            E->sphere.sphs[0][p] *= density_surf;
        }
    }

    // Ylm expansion of CMB mass:
    if (E->parallel.me_loc[3]==0)  {
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            // scale nondim stress -> nondim height of cmb boundary
            E->Xsurf[2][m][j] = X_cmb[m][j]/E->ve_data_cont.botm_scaling;
        }
        sphere_expansion_VE(E,0,E->Xsurf[2],
                          E->sphere.sphc[1],E->sphere.sphs[1],E->output.llmax);
        for (ll=0;ll<=E->output.llmax;ll++)
        for (mm=0;mm<=ll;mm++)   {
            p = E->sphere.hindex[ll][mm];
            E->sphere.sphc[1][p] *= density_cmb;
            E->sphere.sphs[1][p] *= density_cmb;
        }
    }

    if (E->parallel.nprocz>1)  // if >1 cap in z-direction (probably not)
        exchange_sphcs(E,E->sphere.sphc[0],E->sphere.sphs[0],
                         E->sphere.sphc[1],E->sphere.sphs[1]);

    // Now calculate potential:
        // cmb:
    if (E->parallel.me_loc[3]==0)  {
      for (m=1;m<=E->sphere.caps_per_proc;m++)
      for (j=1;j<=E->lmesh.nsf;j++) {
        potential_cmb[m][j] = 0.0;
        for (ll=1;ll<=E->output.llmax;ll++)  
        for (mm=0;mm<=ll;mm++)   { 
            p = E->sphere.hindex[ll][mm]; 
            potential_cmb[m][j] += ( E->Tbl_cs[m][mm][j]*
              (brll1[ll]*E->sphere.sphc[0][p] + brll2[ll]*E->sphere.sphc[1][p])
               + E->Tbl_sn[m][mm][j]*
              (brll1[ll]*E->sphere.sphs[0][p] + brll2[ll]*E->sphere.sphs[1][p]))
                *E->Tbl_lm[m][p][j];
        }
      }
    }
        // surface:
    if (E->parallel.me_loc[3]==E->parallel.nprocz-1)   {
      for (m=1;m<=E->sphere.caps_per_proc;m++)
      for (j=1;j<=E->lmesh.nsf;j++) {
        potential_surf[m][j] = 0.0; 
        for (ll=1;ll<=E->output.llmax;ll++)   
        for (mm=0;mm<=ll;mm++)   { 
            p = E->sphere.hindex[ll][mm]; 
            potential_surf[m][j] += ( E->Tbl_cs[m][mm][j]*
             (srll1[ll]*E->sphere.sphc[0][p] + srll2[ll]*E->sphere.sphc[1][p])
                    + E->Tbl_sn[m][mm][j]*
             (srll1[ll]*E->sphere.sphs[0][p] + srll2[ll]*E->sphere.sphs[1][p]) )
                *E->Tbl_lm[m][p][j];
        }
      }
    }

    // alter the Y_21 potential, if polar_wander is on:
    if (E->ve_data_cont.polar_wander && icon==1)  
        // Xsurf[1/2] have already been converted to nondim height of boundary
//        polar_wander_effects( E, E->Xsurf[1], E->Xsurf[2], 
//                                 potential_surf, potential_cmb );
        polar_wander_effects( E, X_surf, X_cmb, 
                                 potential_surf, potential_cmb );

    return;
}


void calculate_potential_deg1_2(E,X_surf,X_cmb)
    struct All_variables *E;
    double **X_surf;
    double **X_cmb;
{
    int llmax,ib,is,m,ll,ll1,ll2,mm,p,i,j,k,n;
    double con,r,t,f,rir,ri,ro,modified_plgndr_a();
    double density_surf,density_cmb;

    static int been=0;
    static double brll1[65],brll2[65];
    static double srll1[65],srll2[65];
    void  sphere_expansion_VE();
    void  exchange_sphcs();

    ri = E->sphere.ri;
    ro = E->sphere.ro;
    density_surf = 1.0;
    density_cmb = (E->data.density_below-E->data.density)/E->data.density;

    llmax = 2;
    if (been==0)  {
        been = 1;
        for (ll=1;ll<=llmax;ll++)    {
            srll1[ll] = pow(ro,(double)(ll))/(2.0*ll+1.0); 
            srll2[ll] = ri*pow(ri,(double)(ll+1))/(2.0*ll+1.0); 
        }
    }

    // Ylm expansion of surface mass:
    if (E->parallel.me_loc[3]==E->parallel.nprocz-1)   {
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            // scale nondim stress -> nondim height of rock
            E->Xsurf[1][m][j] = X_surf[m][j]/E->ve_data_cont.surf_scaling;
        }
        sphere_expansion_VE(E,1,E->Xsurf[1],
                             E->sphere.sphc[0],E->sphere.sphs[0],llmax);
        for (ll=0;ll<=llmax;ll++)
        for (mm=0;mm<=ll;mm++)   {
            p = E->sphere.hindex[ll][mm];
            E->sphere.sphc[0][p] *= density_surf;
            E->sphere.sphs[0][p] *= density_surf;
        }
    }

    // Ylm expansion of CMB mass:
    if (E->parallel.me_loc[3]==0)  {
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            // scale nondim stress -> nondim height of cmb boundary
            E->Xsurf[2][m][j] = X_cmb[m][j]/E->ve_data_cont.botm_scaling;
        }
        sphere_expansion_VE(E,0,E->Xsurf[2],
                             E->sphere.sphc[1],E->sphere.sphs[1],llmax);
        for (ll=0;ll<=llmax;ll++)
        for (mm=0;mm<=ll;mm++)   {
            p = E->sphere.hindex[ll][mm];
            E->sphere.sphc[1][p] *= density_cmb;
            E->sphere.sphs[1][p] *= density_cmb;
        }
    }

    if (E->parallel.nprocz>1)  // if >1 cap in z-direction (probably not)
        exchange_sphcs(E,E->sphere.sphc[0],E->sphere.sphs[0],
                         E->sphere.sphc[1],E->sphere.sphs[1]);

    // Now calculate potential:

    ll=1; mm=0;  
    p = E->sphere.hindex[ll][mm]; 
    E->ve_data_cont.CM_pot[0]= srll1[ll]*E->sphere.sphc[0][p]+srll2[ll]*E->sphere.sphc[1][p];

    ll=1; mm=1;  
    p = E->sphere.hindex[ll][mm]; 
    E->ve_data_cont.CM_pot[1]= srll1[ll]*E->sphere.sphc[0][p]+srll2[ll]*E->sphere.sphc[1][p];
    E->ve_data_cont.CM_pot[2]= srll1[ll]*E->sphere.sphs[0][p]+srll2[ll]*E->sphere.sphs[1][p];

    ll=2; mm=1;  
    p = E->sphere.hindex[ll][mm]; 
    E->ve_data_cont.PW_pot[0]= srll1[ll]*E->sphere.sphc[0][p]+srll2[ll]*E->sphere.sphc[1][p];
    E->ve_data_cont.PW_pot[1]= srll1[ll]*E->sphere.sphs[0][p]+srll2[ll]*E->sphere.sphs[1][p];

  return;

  }



/*===========================================================================
 * update_potential_time() called once in Visco_elastic.c at the end of each 
 * time step.
 * Accumulate E->incr_potential[0/1] into E->init_potential[0/1].
 *
 * If we have discontinued self-grav iteration, set pred_potential[0/1] with
 *   pred = init + incr *fraction
 *=========================================================================== */
void update_potential_time(E)
    struct All_variables *E;
{
    int ib,is,m,ll,ll1,ll2,mm,p,i,j,k,n;
    double fraction = 1.0;
    FILE *fp;

    for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (j=1;j<=E->lmesh.nsf;j++)   {
        E->init_potential[1][m][j] += E->incr_potential[1][m][j];
        E->init_potential[0][m][j] += E->incr_potential[0][m][j];
    }

    if (E->monitor.solution_cycles>=E->ve_data_cont.iteration)   {
        if ( E->advection.timestep != E->advection.next_timestep )
            fraction = E->advection.next_timestep / E->advection.timestep ;

        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            E->pred_potential[1][m][j] = E->init_potential[1][m][j] 
                                       + E->incr_potential[1][m][j] *fraction;
            E->pred_potential[0][m][j] = E->init_potential[0][m][j] 
                                       + E->incr_potential[0][m][j] *fraction;
        }
    }

    return;
}

/*===========================================================================
 * get_potential(E,count)
 *===========================================================================
 * Sets E->potential[0/1], the nondim grav'l potential at the surface/cmb.
 *               |  pred      (if there is no self-grav iteration)
 *   potential = |  init      (for the first step in a self-grav iteration)
 *               |  init+incr (if in the middle of self-grav interation)
 *=========================================================================== */
void get_potential(E,count)
    struct All_variables *E;
    int count;
{
    int ib,is,m,ll,ll1,ll2,mm,p,i,j,k,n;
    void calculate_potential();
    void parallel_process_termination();
    double total_surface_integral();

/*    double temp1,*TG[4];

  for (m=1;m<=E->sphere.caps_per_proc;m++)
    TG[m] = (double *)malloc((E->lmesh.nsf+1)*sizeof(double));
*/
    if (count==0)   {  // => first (perhaps only) visit here for this timestep
        if (E->monitor.solution_cycles > E->ve_data_cont.iteration)   {
            // no self-grav iteration. will not come back here this timestep
            for (m=1;m<=E->sphere.caps_per_proc;m++)
            for (j=1;j<=E->lmesh.nsf;j++)   {
                E->potential[1][m][j] = E->pred_potential[1][m][j];  // cmb
                E->potential[0][m][j] = E->pred_potential[0][m][j];  // surface
            }
        }
        else  {
            // We are performing self-grav iteration. So initialize E->potential
            // with the potential at the beginning of the timestep.
            for (m=1;m<=E->sphere.caps_per_proc;m++)
            for (j=1;j<=E->lmesh.nsf;j++)   {
                E->potential[1][m][j] = E->init_potential[1][m][j];
                E->potential[0][m][j] = E->init_potential[0][m][j];
            }
        }
    }

    else  {   // second time or later in self-grav iteration

        // calculate E->incr_potential[0/1] from E->slice.surf/botm[2]:
        calculate_potential( E, E->slice_ve.surf[2], E->slice_ve.botm[2], 
                             E->incr_potential[0], E->incr_potential[1], 1);

        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)   {
            E->potential[1][m][j] =  E->init_potential[1][m][j] 
                                   + E->incr_potential[1][m][j];  // cmb
            E->potential[0][m][j] =  E->init_potential[0][m][j] 
                                   + E->incr_potential[0][m][j];  // surface
        }
    }

/*
for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (j=1;j<=E->lmesh.nsf;j++)  { 
         TG[m][j] = fabs(E->potential[0][m][j]);
            }
temp1=total_surface_integral(E,TG,1);
if (E->parallel.me==0) fprintf(stderr,"in get_potential %g count %d\n",temp1,count);
    parallel_process_termination();

  free ((void *)TG);
*/

    return;
}

/* ======================================================= 
   for each element el on boundaries, determine contributions
   from incremental displacement. Only the matrix is determined
   here.
 =======================================================  */
void  construct_B_R(E)
  struct All_variables *E;
 {

  void get_global_1d_shape_fn_2();
  void  exchange_id_d();

  const int onedp=onedvpoints[E->mesh.nsd];

  struct Shape_function1 GM;
  struct Shape_function1_dA dGammax;

  double con,slope;
  double temp,x[3][3],force[9],force_at_gs[9];
  int lev,m,ic,nn[5],e,el, i, k, p, p2, lnode[5];

 if (E->parallel.me_loc[3]==E->parallel.nprocz-1 || E->parallel.me_loc[3]==0)  {
 for (lev=E->mesh.levmax;lev>=E->mesh.levmin;lev--)     
 for (m=1;m<=E->sphere.caps_per_proc;m++)   {

   if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  
     for (e=1;e<=E->lmesh.SNEL[lev];e++)    {
       ic = 1;     /*top  */
       el = e*E->lmesh.ELZ[lev];

       get_global_1d_shape_fn_2(E,el,&GM,&dGammax,ic,lev,m);

       for(k=1;k<=onedp;k++)
          nn[k] = k+ic*onedp;

       for(k=1;k<=onedp;k++)
         for (i=1;i<=onedp;i++)
           E->B_R[lev][m][nn[k]][(e-1)*onedp+i] =
                     E->M.vpt[GMVINDEX(k,i)]
                     * dGammax.vpt[GMVGAMMA(0,i)];
       }
   if (E->parallel.me_loc[3]==0)  
     for (e=1;e<=E->lmesh.SNEL[lev];e++)     {
       ic = 0;     /*bottom  */
       el = (e-1)*E->lmesh.ELZ[lev]+1;

       get_global_1d_shape_fn_2(E,el,&GM,&dGammax,ic,lev,m);

       for(k=1;k<=onedp;k++)
          nn[k] = k+ic*onedp;

       for(k=1;k<=onedp;k++)
         for (i=1;i<=onedp;i++)
           E->B_R[lev][m][nn[k]][(e-1)*onedp+i] =
                     E->M.vpt[GMVINDEX(k,i)]
                     * dGammax.vpt[GMVGAMMA(0,i)];
       }
    }
  }

 return;
 }

/*===========================================================================
 * add_restoring(E,lev,m,Au,u)
 *===========================================================================*/
void add_restoring(E,lev,m,Au,u)
    struct All_variables *E;
    double **Au,**u;
    int lev,m;
{

    const int onedp=onedvpoints[E->mesh.nsd];

    double temp,x[3][3],force[9],force_at_gs[9];
    int ic,nn[5],el,e, i, k, p, p2, lnode[5];

    if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  {

        for (e=1;e<=E->lmesh.SNEL[lev];e++)   {
            el=e*E->lmesh.ELZ[lev];

            for(k=1;k<=onedp;k++)   {
                nn[k] = E->ID[lev][m][E->IEN[lev][m][el].node[k+onedp]].doff[3];
                force[k] = E->ve_data_cont.surf_scaling*u[m][nn[k]];
            }

            for (i=1;i<=onedp;i++)   {
                force_at_gs[i] = 0.0;
                for(k=1;k<=onedp;k++)
                    force_at_gs[i] += force[k] * E->M.vpt[GMVINDEX(k,i)];
            }

            for (k=1;k<=onedp;k++)
            for (i=1;i<=onedp;i++)
                Au[m][nn[k]] += E->B_R[lev][m][k+onedp][(e-1)*onedp+i] * force_at_gs[i];

        }
    }

    if (E->parallel.me_loc[3]==0)  {

        for (e=1;e<=E->lmesh.SNEL[lev];e++)   {
            el=(e-1)*E->lmesh.ELZ[lev]+1;

            for(k=1;k<=onedp;k++)   {
                nn[k] = E->ID[lev][m][E->IEN[lev][m][el].node[k]].doff[3];
                force[k] = E->ve_data_cont.botm_scaling*u[m][nn[k]];
            }

            for (i=1;i<=onedp;i++)   {
                force_at_gs[i] = 0.0;
                for(k=1;k<=onedp;k++)
                    force_at_gs[i] += force[k] * E->M.vpt[GMVINDEX(k,i)];
            }

            for(k=1;k<=onedp;k++)
            for (i=1;i<=onedp;i++)
                Au[m][nn[k]] += E->B_R[lev][m][k][(e-1)*onedp+i] * force_at_gs[i];

        }
    }

    return;
}

/* =============================================================================
 * apply_new_loads (E)
 * =============================================================================
 * At the beginning of each timestep, just after setting the current value for
 * iceload (in get_ice3g, for example), this routine will prepare the following
 * for the stokes solver:
 *     slice.load[0/2]
 *     init_potential[1/0]
 *     pred_potential[1/0]
 * Also, the degree-1 iceload is changed via load_to_CM.
 * About the flag E->control.change_of_load:
 *     0 => incr loads are same as last timestep (eg, within an epoch)
 *     1 => incr loads are changing from prev timestep
 *     2 => incr loads are all zero (eg, the last 4kyrs, post-glacial)
 * ===========================================================================*/

void apply_new_loads(E)  
    struct All_variables *E;
{
    int m,i;
    void calculate_potential();
    double total_surface_integral();
    double temp1,temp2;
    void parallel_process_termination();
    void load_to_CM();
    void load_to_CM_grav();

    if (E->ve_data_cont.change_of_load==0) {  // no more ice or static ocean load
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (i=1;i<=E->lmesh.nsf;i++)   {
            E->incr_potential[2][m][i] = 0.0 ;
            E->incr_potential[3][m][i] = 0.0 ;
        }
        return;
    }

    if (E->ve_data_cont.Heaviside==2) {  // only for ice-3g type loading

        // Put loads into slice.surf/botm[2]:
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)
                E->slice_ve.surf[2][m][i] =  E->slice_ve.iceload[0][m][i]
                                        + E->slice_ve.static_oceanload[m][i];
        if (E->parallel.me_loc[3]==0)
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)
                E->slice_ve.botm[2][m][i] = 0.0;

        // Adjust loads to prevent CM motion (the 1 flag will overwrite the
        // current data.CM_incr, starting fresh for this timestep):
        load_to_CM_grav( E, E->slice_ve.surf[2], E->slice_ve.botm[2], 1 );

        // Add these loads into slice.load[0/2] (which is used in
        // assemble_forces to create force vector):
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)
                E->slice_ve.load[0][m][i] +=  E->slice_ve.surf[2][m][i];
        if (E->parallel.me_loc[3]==0)
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)
                E->slice_ve.load[2][m][i] += E->slice_ve.botm[2][m][i];

    } // end if ice-3g

    if (E->ve_data_cont.SELFG)   {

        // if the loads have changed, find their new incremental potential due
        // to incremental loads from ice and static ocean loads:
        if (E->ve_data_cont.change_of_load==1 || E->ve_data_cont.SLE)
            // Note: if we're using the SLE, the static_oceanload does not
            // change in a uniform way (due to the time-dependant ocean
            // function).  So we have to recalculate the incr_potential every
            // timestep.
            calculate_potential( E, E->slice_ve.surf[2], E->slice_ve.botm[2], 
                                 E->incr_potential[2], E->incr_potential[3], 1);

        // Add load's incr_potenial to init_ and pred_:
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (i=1;i<=E->lmesh.nsf;i++)   {
            E->init_potential[0][m][i] += E->incr_potential[2][m][i];
            E->init_potential[1][m][i] += E->incr_potential[3][m][i];
        }
        if (E->monitor.solution_cycles>=E->ve_data_cont.iteration)   {
            for (m=1;m<=E->sphere.caps_per_proc;m++)
            for (i=1;i<=E->lmesh.nsf;i++)   {
                E->pred_potential[0][m][i] += E->incr_potential[2][m][i];
                E->pred_potential[1][m][i] += E->incr_potential[3][m][i];
            }
        } // end if make prediction 
    }     // end if self-gravitation

    return;
}


/* =============================================================================
 * get_ice3g(E,iceload)  
 * =============================================================================
 * Specifically for ice-3G loading.
 * Puts new load into iceload[m][n] (n = surface node). Specifically, 
 * iceload is the incremental (ie, per timestep) nondimensional stress, 
 * after removing its average.
 * Only sets (passed in) array 'iceload'.
 * About the flag E->control.change_of_load:
 *     0 => incr loads are same as last timestep (eg, within an epoch)
 *     1 => incr loads are changing from prev timestep
 *     2 => incr loads are all zero (eg, the last 4kyrs, post-glacial)
 * ========================================================================== */

void get_ice3g(E,iceload)  
    struct All_variables *E;
    double **iceload;
{
    FILE *fp;
    int m,i,j,n;
    static int ifile;  // this is the ice3g 'epoch'
    static int been_here=0;
    static int step_prev=0;
    void sphere_expansion_output();
    void parallel_process_termination();
    void read_reg_grids();
    void remove_average();
    double total,temp1, temp2;
    char outfile[255],input_s[200];

    if (been_here==0)  {
        // Allocate and initialize some arrays:
        for (m=1;m<=E->sphere.caps_per_proc;m++)   {
            E->slice_ve.ice_height_prev[m] = (double *)
                              malloc((E->lmesh.nsf+2)*sizeof(double));
            E->slice_ve.ice_height_curr[m] = (double *)
                              malloc((E->lmesh.nsf+2)*sizeof(double));
            for (n=1;n<=E->lmesh.nsf;n++)  {  
                E->slice_ve.ice_height_prev[m][n] = 0.0;
                E->slice_ve.ice_height_curr[m][n] = 0.0;
            }
        } // end allocate & initialize

    }

   if (E->ve_data_cont.DIRECT == 0 && been_here!=0) 
        return;

    been_here ++;

        // Read in the iceload for each epoch. 

    ifile = E->ve_data_cont.stage + 1;

    // The following flag will force a re-calculation of load potential in
    // apply_new_loads:
    E->ve_data_cont.change_of_load = 1;

    if (ifile==1)  {       // for the first epoch 
        sprintf(outfile,"%s%dx%d.%d",
            E->ve_data_cont.ice_file, E->sphere.elx, E->sphere.ely, ifile-1);
        read_reg_grids(E,outfile,E->slice_ve.ice_height_prev);
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)  {
           E->slice_ve.ice_height_prev[m][j] = E->slice_ve.ice_height_prev[m][j]/E->sphere.dradius; // non-dimensionalized by the Earth's radius
           E->slice_ve.ice_height_prev[m][j] = 0.0; // reset to be ice free
           }
        step_prev = 0;
        }
    else if (ifile>1)  {       // if we're beyond the first epoch, curr->prev
        for (m=1;m<=E->sphere.caps_per_proc;m++)
        for (j=1;j<=E->lmesh.nsf;j++)  
            E->slice_ve.ice_height_prev[m][j] = E->slice_ve.ice_height_curr[m][j];   
        step_prev = E->ve_data_cont.stages_step[E->ve_data_cont.stage-1];
        }

    // read new epoch data into slice.ice_height_curr
    //
    sprintf(outfile,"%s%dx%d.%d",
                E->ve_data_cont.ice_file, E->sphere.elx, E->sphere.ely, ifile);
    read_reg_grids(E,outfile,E->slice_ve.ice_height_curr);

    for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (j=1;j<=E->lmesh.nsf;j++)  {
        E->slice_ve.ice_height_curr[m][j] = E->slice_ve.ice_height_curr[m][j]/E->sphere.dradius; // non-dimensionalized by the Earth's radius
    }
    
    // temp1 is height->stress scaling / number of timesteps in this epoch
    temp1 = E->ve_data_cont.ice_stress_scale/(E->ve_data_cont.stages_step[E->ve_data_cont.stage] - step_prev);

    // iceload now becomes incremental (ie, per timestep) nondimensional stress
    for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (j=1;j<=E->lmesh.nsf;j++) 
        iceload[m][j] = ( E->slice_ve.ice_height_curr[m][j]
                         -E->slice_ve.ice_height_prev[m][j])*temp1;

    // remove average and save the spherical harmonic coefficients:
    for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (n=1;n<=E->lmesh.nsf;n++)    
        E->Xsurf[3][m][n] = iceload[m][n];
    remove_average(E,E->Xsurf[3],1);
    sprintf(outfile,"iceload_stage%d",ifile);

    sphere_expansion_output( E, 1, E->Xsurf[3], 
                             E->sphere.sphc[0], E->sphere.sphs[0],
                             E->monitor.solution_cycles,outfile );
    for (m=1;m<=E->sphere.caps_per_proc;m++)
    for (n=1;n<=E->lmesh.nsf;n++)
        iceload[m][n] = E->Xsurf[3][m][n];

    return;
}

////////////////////////////////////////////////////////
/////////////////////////////////////////////////////
//
 void read_reg_grids(E,outfile,field)
   struct All_variables *E;
   char *outfile;
   double **field;   
  {

char input_s[1000];
FILE *fp2;

void  parallel_process_termination();
int numtheta,numphi,nregnodes;
int kk,j;
int ntheta,nphi,iregnode,iregnode2;
int node;
int c1,c2,c3,c4;
int isurface_element,lev;

double del_degree;
double del_theta;
double del_phi;
double lat_min,lat_max;
double theta_min,theta_max;
double phi_min,phi_max;
double vphi;
double rlat,rlong;
double theta,phi;
double phiprime,thetaprime;
double xi,eta;
double shape1,shape2,shape3,shape4;

static double *regular_f;
static int been_here=0;

/* INPUT FILE SPECIFIC STUFF */
/* format longitude, latitude, vphi, vtheta (vtheta is opposite in convention) */
/* file sequence given in specific order (see below):                          */
/* inputfile specific parameters:                                              */

 if (E->sphere.nox==181) {
   del_degree=1.0;           /* increments given in input file */
   lat_min=-89.5;            /* minimum lattitude */
   lat_max=89.5;             /* maximum lattitude */
   phi_min=0.5;             /* minimum longitude */
   phi_max=359.5;           /* maximum longitude */
   numtheta=180;             /* number of theta increments */
   numphi=360;               /* number of phi increments */
  }
 else if (E->sphere.nox==361) {
   del_degree=0.5;           /* increments given in input file */
   lat_min=-89.75;            /* minimum lattitude */
   lat_max=89.75;             /* maximum lattitude */
   phi_min=0.25;             /* minimum longitude */
   phi_max=359.75;           /* maximum longitude */
   numtheta=360;             /* number of theta increments */
   numphi=720;               /* number of phi increments */
  }
 
 
   del_theta=del_degree*M_PI/180.0;
   del_phi=del_degree*M_PI/180.0;
   theta_min=-1.0*(lat_max-90.0)*M_PI/180.0;
   theta_max=-1.0*(lat_min-90.0)*M_PI/180.0;
   phi_min=phi_min*M_PI/180.0;
   phi_max=phi_max*M_PI/180.0;

   nregnodes=numtheta*numphi;


/* adjust parameters for ghosting - extra regular elements are added on all sides */
/* This is required to interpolate nodes between thetamin and thetamax, and phimin and phimax */
/* Domain is padded by extra +2 numphi and +2 numtheta */

   numtheta=numtheta+2;
   numphi=numphi+2;
   theta_min=theta_min-del_theta;
   theta_max=theta_max+del_theta;
   phi_min=phi_min-del_phi;
   phi_max=phi_max+del_phi;

   nregnodes=numtheta*numphi;

 if (been_here==0)  {
   regular_f = (double *)malloc((nregnodes+1)*sizeof(double));
   been_here = 1;
   }


/* read from file */

   if ( (fp2=fopen(outfile,"r"))==NULL)   {
      fprintf(stderr,"ERROR(read_reg_grids)- file %s not found\n",outfile);
      fflush(stderr);
      parallel_process_termination();
   }

   for (kk=1;kk<=nregnodes;kk++)
      regular_f[kk]=-999999;

/* input file specific order of reading  right here */
/* (note - leaving room for ghosting) */

//   for (ntheta=(numtheta-1);ntheta>1;ntheta--)
   for (ntheta=2;ntheta<=(numtheta-1);ntheta++)
     for (nphi=2;nphi<=(numphi-1);nphi++)     {

      iregnode=ntheta+(nphi-1)*numtheta;

      if ((iregnode>nregnodes)||(iregnode<1))   {
        fprintf(stderr,"ERROR(plate velocities)-wrong iregnode %d %d\n",iregnode,nregnodes);
        fflush(stderr);
        exit(10);
      }

      fgets(input_s,1000,fp2);
      sscanf(input_s,"%lf %lf %le",&rlong,&rlat,&vphi);

     regular_f[iregnode]=vphi;

   }

   fclose(fp2);

/* ghost sides of regular domain */

   nphi=1;
   for (ntheta=2;ntheta<=(numtheta-1);ntheta++)  {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=ntheta+((numphi-1)-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }

   nphi=numphi;
   for (ntheta=2;ntheta<=(numtheta-1);ntheta++)   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=ntheta+(2-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }

   ntheta=1;
   for (nphi=1;nphi<=(numphi/2);nphi++)   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta+1)+(nphi+numphi/2-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }
   for (nphi=(numphi/2)+1;nphi<=numphi;nphi++)   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta+1)+(nphi-(numphi/2)-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }

   ntheta=(numtheta);
   for (nphi=1;nphi<=(numphi/2);nphi++)   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta-1)+(nphi+numphi/2-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }
   for (nphi=(numphi/2)+1;nphi<=numphi;nphi++)  {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta-1)+(nphi-(numphi/2)-1)*numtheta;
      regular_f[iregnode]=regular_f[iregnode2];
   }

/* interpolate real mesh */

   isurface_element=0;
   for (j=1;j<=E->sphere.caps_per_proc;j++)
   for (node=1;node<=E->lmesh.nno;node++)   {
     theta=E->sx[j][1][node];
     phi  =E->sx[j][2][node];
     if (node%E->lmesh.noz==0)  {
        isurface_element++;
/* find position on regular mesh */

        ntheta=((theta-theta_min)/del_theta)+1;
        nphi=((phi-phi_min)/del_phi)+1;

/* iregnode is the lower left node in the regular element */

        iregnode=ntheta+(nphi-1)*numtheta;

/* find theta and phi distance from node */

        thetaprime=theta-(theta_min+(ntheta-1)*del_theta);
        phiprime=phi-(phi_min+(nphi-1)*del_phi);

        if (thetaprime<0.0 || thetaprime>del_theta)  {
           fprintf(stderr,"ERROR(get plate velocities)-wierd thetaprime %f %f\n",thetaprime,del_theta);
           fflush(stderr);
           exit(10);
        }
        if (phiprime<0.0 || phiprime>del_phi)   {
           fprintf(stderr,"ERROR(get plate velocities)-wierd phiprime %f %f\n",phiprime,del_phi);
           fflush(stderr);
           exit(10);
        }

/* determine shape functions */

       xi=2.0/del_theta*thetaprime-1.0;
       eta=2.0/del_phi*phiprime-1.0;

       if (xi<(-1-1e-6) || xi > (1+1e-6) || eta < (-1-1e-6) || eta > (1+1e-6))  {
          fprintf(stderr,"bad local variables %f %f (%f %f) (%f %f)\n",xi,eta,thetaprime,phiprime,del_theta,del_phi);
          fflush(stderr);
          exit(10);
       }
       shape1=0.25*(1.0-xi)*(1.0-eta);
       shape2=0.25*(1.0+xi)*(1.0-eta);
       shape3=0.25*(1.0+xi)*(1.0+eta);
       shape4=0.25*(1.0-xi)*(1.0+eta);

       c1=iregnode;
       c2=iregnode+1;
       c3=iregnode+1+numtheta;
       c4=iregnode+numtheta;

       if ( (c3>(numtheta*numphi)) || (c1<1) )  {
         fprintf(stderr,"ERROR(get plate...) - %d %d %d %d\n",c1,c2,c3,c4);
         fflush(stderr);
         exit(10);
       }

       vphi = regular_f[c1]*shape1+regular_f[c2]*shape2
            + regular_f[c3]*shape3+regular_f[c4]*shape4;

       field[j][isurface_element]=vphi;

     }
   }

return;
}
