/* -------------------------------------------------------------------------
  This version of CitcomSVE code is built from CIG version of CitcomS 3.1.
  CitcomSVE solves viscoelastic response of a planetary mantle to surface loads
  or tidal potential load. The original version of CitcomSVE had been built 
  from 2002 to 2013 out of the original version of CitcomS predated CIG by 
  Shijie Zhong, Archie Paulson, Geruo A, and John Wahr (Zhong et al., 2003; 
  Paulson et al., 2005; A et al., 2013). The current version was built to make
  the use of improved domain decomposition of CIG version of CitcomS, which 
  enables parallel computing on a much larger scale than the original version
  of CitcomSVE. The rebuilding and migration of the code started in the fall 
  of 2019, but the main work including full benchmarks was largely carried out
  in 2020 as we were trapped at home by the Pandemic.
                                              Shijie Zhong
                                             December 2, 2020
 -------------------------------------------------------------------------- */
/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 
 *<LicenseText>
 *
 * CitcomS by Louis Moresi, Shijie Zhong, Lijie Han, Eh Tan,
 * Clint Conrad, Michael Gurnis, and Eun-seo Choi.
 * Copyright (C) 1994-2005, California Institute of Technology.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *</LicenseText>
 * 
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#include "interuption.h"

void parallel_process_termination();

int Emergency_stop;



void interuption(int signal_number)
{
  if (Emergency_stop)
    parallel_process_termination();
  else
    Emergency_stop++;
  fprintf(stderr,"Cleaning up before exit\n");
  return;
}


void set_signal()
{
  Emergency_stop = 0;

  signal(SIGINT,interuption);
  signal(SIGTERM,interuption);
  return;
}



