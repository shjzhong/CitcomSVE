/* -------------------------------------------------------------------------
  This version of CitcomSVE code is built from CIG version of CitcomS 3.1.
  CitcomSVE solves viscoelastic response of a planetary mantle to surface loads
  or tidal potential load. The original version of CitcomSVE had been built 
  from 2002 to 2013 out of the original version of CitcomS predated CIG by 
  Shijie Zhong, Archie Paulson, Geruo A, and John Wahr (Zhong et al., 2003; 
  Paulson et al., 2005; A et al., 2013). The current version was built to make
  the use of improved domain decomposition of CIG version of CitcomS, which 
  enables parallel computing on a much larger scale than the original version
  of CitcomSVE. The rebuilding and migration of the code started in the fall 
  of 2019, but the main work including full benchmarks was largely carried out
  in 2020 as we were trapped at home by the Pandemic.
                                              Shijie Zhong
                                             December 2, 2020
 -------------------------------------------------------------------------- */

#include <math.h>
#include <sys/types.h>
#include "element_definitions.h"
#include "global_defs.h"
#include "parsing.h"

void process_new_velocity(struct All_variables *E,int ii)
{
    void output_velo_related();
    void get_STD_topo();
    void get_CBF_topo();
    void parallel_process_sync();
    void gravity_geoid();
    void interp_surf_velocity();
    void parallel_process_termination();

    void update_stress_strain();

    void print_surf_topo();
    void deform_grid();
    void calculate_potential();
    void update_potential_time();

    static int been_here=0;


    int m,i,it;
    FILE *fp;

    if(been_here==0) {
       E->monitor.length_scale = E->data.layer_km/E->mesh.layer[2]; /* km */
       E->monitor.time_scale = pow(E->data.layer_km*1000.0,2.0)/
            (E->data.therm_diff*3600.0*24.0*365.25*1.0e6);   /* Million years */
        been_here++;
    }
    update_stress_strain(E,ii);

    deform_grid(E);

    if (E->ve_data_cont.SELFG)   {
      // calculate E->incr_potential[0/1] from slice.surf/botm[2]
      // (note: surf/botm[2] is set in deform_grid)
      calculate_potential( E, E->slice_ve.surf[2], E->slice_ve.botm[2],
                       E->incr_potential[0], E->incr_potential[1], 1 );

      // Add the incr_potential (due to deformation) into init_potential
      // and set pred_potential = init_potential + f*incr_potential
      update_potential_time(E);

      if (E->ve_data_cont.polar_wander) {
         E->ve_data_cont.PW[0] += E->ve_data_cont.PW_incr[0];
         E->ve_data_cont.PW[1] += E->ve_data_cont.PW_incr[1];
if (E->parallel.me==0) fprintf(E->fp,"m0m1 in process_new_ve %g %g\n",E->ve_data_cont.PW_incr[0],E->ve_data_cont.PW_incr[1]);
         }

      // Now init_potential has the potential due to the current (completed)
      // deformation and iceload, and pred_potential has the same with an
      // extra incr_potential for extrapolation.
    }

    print_surf_topo(E,ii);

    parallel_process_sync(E);
    return;
}

 //==========================================================================
 /* ========================================================================== */

void pickup_dt(struct All_variables *E)
{
    int i,j;
    void std2_timestep();

        std2_timestep(E);  // for viscoelastic models

    return;
}


/* ==========================================================================
 * deform_grid(E)
 * ==========================================================================
 * Calculates the new positions of each nodes by adding the displacements onto
 * the old coordinates for each nodes. And inject the new positions onto
 * different levels for multigrid.
 * Also, sets:  
 *       E->slice.surf/botm[1]    incr deformation (from E->U)
 *       E->slice.surf/botm[2]    incr stresses    (no iceload)
 *       E->slice.surf/botm[3]    cum  deformation (+= surf/botm[1])
 *       E->slice.load[0/2]       cum  stresses, w/ iceload (+= surf/botm[2])
 * ========================================================================== */

void deform_grid(struct All_variables *E)
{
    void inject_grid();
    void mass_matrix();
    void remove_average();
    void get_cmb_topo();   
    void parallel_process_termination();
    void load_to_CM(), load_to_CM_grav(), shift_to_CM() ;

    double sint,cost,sinf,cosf,ux,uy,uz,myatan();
    int node,count,i,j,lev,m;

    lev=E->mesh.levmax;

    for (m=1;m<=E->sphere.caps_per_proc;m++)  
      for (i=1;i<=E->lmesh.nno;i++)  {
         sint = E->SinCos[lev][m][0][i];
         sinf = E->SinCos[lev][m][1][i];
         cost = E->SinCos[lev][m][2][i];
         cosf = E->SinCos[lev][m][3][i];

         ux = E->U[m][E->id[m][i].doff[1]]*cost*cosf
            - E->U[m][E->id[m][i].doff[2]]*sinf
            + E->U[m][E->id[m][i].doff[3]]*sint*cosf;
         uy = E->U[m][E->id[m][i].doff[1]]*cost*sinf
            + E->U[m][E->id[m][i].doff[2]]*cosf
            + E->U[m][E->id[m][i].doff[3]]*sint*sinf;
         uz =-E->U[m][E->id[m][i].doff[1]]*sint
            + E->U[m][E->id[m][i].doff[3]]*cost;

         E->X[lev][m][1][i] += ux;
         E->X[lev][m][2][i] += uy;
         E->X[lev][m][3][i] += uz;

         E->SX[lev][m][3][i] += E->U[m][E->id[m][i].doff[3]];
         E->SX[lev][m][1][i] = acos(E->X[lev][m][3][i]/E->SX[lev][m][3][i]);
         E->SX[lev][m][2][i] = myatan(E->X[lev][m][2][i],E->X[lev][m][1][i]);
         
         E->SinCos[lev][m][0][i] = sin(E->SX[lev][m][1][i]);
         E->SinCos[lev][m][1][i] = sin(E->SX[lev][m][2][i]);
         E->SinCos[lev][m][2][i] = cos(E->SX[lev][m][1][i]);
         E->SinCos[lev][m][3][i] = cos(E->SX[lev][m][2][i]);
      }

  if (E->control.NMULTIGRID||E->control.EMULTIGRID)   {
      inject_grid(E); 
      }

    if (E->monitor.solution_cycles%E->ve_data_cont.KERNEL==0 || E->ve_data_cont.DIRECT)  {
        mass_matrix(E);
    }

    /* done with updating grids */

        /* We are at the end of the timestep, so do some post-processing.
         * Put the final incremental deformation into slice.surf/botm[1];
         * these fields will be used for writing out results and accumulating
         * into slice.surf/botm[3].
         * Also put incremental stresses from the current timestep into
         * slice.surf/botm[2] for calculation of CM motion (below).    */
        // surface:
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  {
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)  {
                node = i*E->lmesh.noz;
                E->slice_ve.surf[1][m][i] = E->U[m][E->id[m][node].doff[3]];
            }
            remove_average(E,E->slice_ve.surf[1],1);

            if (E->ve_data_cont.Heaviside==1)  {   /* single-harmonic */
                for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (i=1;i<=E->lmesh.nsf;i++)
                    E->slice_ve.surf[2][m][i] = E->slice_ve.surf[1][m][i]
                                            *E->ve_data_cont.surf_scaling;
            }
            else if (E->ve_data_cont.Heaviside==2) {    /* ice-3g  */
                for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (i=1;i<=E->lmesh.nsf;i++)
                    E->slice_ve.surf[2][m][i] = E->slice_ve.surf[1][m][i]
                                              *E->ve_data_cont.surf_scaling 
                                            + E->slice_ve.dynamic_oceanload[m][i];
            }
            else if (E->ve_data_cont.Heaviside==3) {    /* ice caps */
                for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (i=1;i<=E->lmesh.nsf;i++)
                    E->slice_ve.surf[2][m][i] = E->slice_ve.surf[1][m][i]
                                            *E->ve_data_cont.surf_scaling 
                                     + E->slice_ve.iceload[E->ve_data_cont.stage][m][i];
            }
        }
        // cmb:
        if (E->parallel.me_loc[3]==0)  {
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)  {
                node = (i-1)*E->lmesh.noz+1;
                E->slice_ve.botm[1][m][i] = E->U[m][E->id[m][node].doff[3]];
            }
            remove_average(E,E->slice_ve.botm[1],0);

            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)  {
                E->slice_ve.botm[2][m][i] = E->slice_ve.botm[1][m][i]
                                        *E->ve_data_cont.botm_scaling;
            }
        }

        /* Now slice.surf/botm[2] are the dynamic loads due to deformation and 
         * dynamic ocean loads. 
         * Now change the loads in slice.surf/botm[2] so that their CM remains
         * at the origin with load_to_CM. This also adds to the current value
         * of data.CM_incr (that's what the 2 flag means).  Then remove the
         * incremental CM motion from the topography (with shift_to_CM).   */

        if (E->ve_data_cont.change_of_load==0) 
          count=1;   // no more new load or static ocean loads
        else
          count=2;
        load_to_CM_grav( E, E->slice_ve.surf[2], E->slice_ve.botm[2], count );

        if (E->parallel.me_loc[3]==E->parallel.nprocz-1) 
            shift_to_CM(E, E->slice_ve.surf[1] );
        if (E->parallel.me_loc[3]==0) 
            shift_to_CM(E, E->slice_ve.botm[1] );

        /* Accumulate the incremental topography into slice.surf/botm[3]
         * (which are the displacement fields written out in print_surf_topo,
         * and used for the dynamic_oceanload). Also accumulate
         * slice.surf/botm[2] into slice.load[0/2].    */
        // surface:
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  {
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++) {
                E->slice_ve.surf[3][m][i] += E->slice_ve.surf[1][m][i];
                E->slice_ve.load[0][m][i] += E->slice_ve.surf[2][m][i];
            }
        }
        // cmb:
        if (E->parallel.me_loc[3]==0)  {
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (i=1;i<=E->lmesh.nsf;i++)  {
                E->slice_ve.botm[3][m][i] += E->slice_ve.botm[1][m][i];
                E->slice_ve.load[2][m][i] += E->slice_ve.botm[2][m][i];
            }
        }
    
    return;
}

void grid_et_al (struct All_variables *E)
  {

  int lev,nno,nox,noy,noz,i,j,k,m;

  for (lev=E->mesh.levmin;lev<=E->mesh.levmax;lev++)  {
    nox = E->lmesh.NOX[lev];
    noy = E->lmesh.NOY[lev];
    noz = E->lmesh.NOZ[lev];
    nno = E->lmesh.NNO[lev];
    for (m=1;m<=E->sphere.caps_per_proc;m++)  
        for (i=1;i<=nno;i++)  {
          E->X[lev][m][1][i] = E->SX[lev][m][3][i]*sin(E->SX[lev][m][1][i])*cos(E->SX[lev][m][2][i]);
          E->X[lev][m][2][i] = E->SX[lev][m][3][i]*sin(E->SX[lev][m][1][i])*sin(E->SX[lev][m][2][i]);
          E->X[lev][m][3][i] = E->SX[lev][m][3][i]*cos(E->SX[lev][m][1][i]);
          } 

    for (m=1;m<=E->sphere.caps_per_proc;m++)  
      for (i=1;i<=nno;i++)  {
        E->SinCos[lev][m][0][i] = sin(E->SX[lev][m][1][i]);
        E->SinCos[lev][m][1][i] = sin(E->SX[lev][m][2][i]);
        E->SinCos[lev][m][2][i] = cos(E->SX[lev][m][1][i]);
        E->SinCos[lev][m][3][i] = cos(E->SX[lev][m][2][i]);
        }

    }


  return;
  }


/* =============================================================================
 * print_surf_topo(E,ii)
 * =============================================================================
 * Write out topography and potential.
 * ========================================================================== */
void print_surf_topo(struct All_variables *E,int ii)
{

    char outfile[255];
    FILE *fp;
    static FILE *fp1,*fp2;
    int m,node,i,j;
    void sphere_expansion_output();
    static int been_here=0;
    double error, tot, amp, tau, tau1,tau2,tau3,ana1,ana3,ana2, 
           total,seconds_in_a_year,temp[601];
    int ll,mm;
    double modified_plgndr_a(),con,t1;
    void parallel_process_termination();

    if ( been_here == 0 )    {

        // write out mesh coordinates:
        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  {
            sprintf( outfile,"%s.coord_s.%d",
                     E->control.data_file,E->parallel.me);
            fp = fopen(outfile,"w");
            fprintf(fp,"%05d %.5e\n",ii,E->ve_data_cont.tau*E->monitor.elapsed_time);
            j = 0;
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (j=1;j<=E->lmesh.nsf;j++)  { 
                    i=j*E->lmesh.noz;
                    E->Xsurf[1][m][j] = E->SX[E->mesh.levmax][m][1][i];
                    E->Xsurf[2][m][j] = E->SX[E->mesh.levmax][m][2][i];
                    fprintf(fp, "%.4e %.4e \n", 
                                E->Xsurf[1][m][j],E->Xsurf[2][m][j]);
                }
            fclose(fp);

            // the following is to observe the elastic behavior:
            if (1)  {

                sphere_expansion_output(E,1,E->slice_ve.surf[3],
                        E->sphere.sphc[0],E->sphere.sphs[0],
                        E->monitor.solution_cycles,"tps");

                // The following is incr_potential from both deformation and loads:
                for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (j=1;j<=E->lmesh.nsf;j++)
                    E->Xsurf[3][m][j] =  E->incr_potential[0][m][j]  
                                       + E->incr_potential[2][m][j] ;

                sphere_expansion_output(E,1,E->Xsurf[3],
                        E->sphere.sphc[0],E->sphere.sphs[0],
                        E->monitor.solution_cycles,"pttl");

                if (E->ve_data_cont.SLE) {
                    // get the oceanload:
                    for (m=1;m<=E->sphere.caps_per_proc;m++)  
                    for (j=1;j<=E->lmesh.nsf;j++)
                        E->Xsurf[3][m][j] =  E->slice_ve.static_oceanload[m][j]
                                           + E->slice_ve.dynamic_oceanload[m][j];
                    sphere_expansion_output(E,1,E->Xsurf[3],
                            E->sphere.sphc[0],E->sphere.sphs[0],
                            E->monitor.solution_cycles,"oceanload");
                }

                for (i=0;i<2;i++) {
                    fp = (i==0)? stderr : E->fp_out ;
                    fprintf(fp, "Wrote initial topo and potential files.\n");
                    fflush(fp);
                }
            }
        }
    }// end if not been_here

    been_here++;

    if ( ((ii % E->control.record_every) == 0))    {

        if (E->parallel.me_loc[3]==E->parallel.nprocz-1)  {
            //sprintf(outfile,"%s.topo_s.%d.%d",
            //       E->control.data_file2,E->parallel.me,ii);
            sprintf(outfile,"%s.topo_s.%d.%d", 
                   E->control.data_file,E->parallel.me,ii);
            fp = fopen(outfile,"w");
            fprintf(fp,"%05d %.5e %.5e %.5e %.5e %.5e %.5e\n",
                    ii,                                  // timstep
                    E->ve_data_cont.tau*E->monitor.elapsed_time, // current time (years)
                    E->ve_data_cont.tau*E->advection.timestep,  // length of timestep
              E->ve_data_cont.PW[0],E->ve_data_cont.PW[1], // cumu. polar motion
              E->ve_data_cont.PW_incr[0],E->ve_data_cont.PW_incr[1]); // polar motion

            // The following is incr_potential from both deformation [0] and loads [2]:
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (j=1;j<=E->lmesh.nsf;j++)
                E->Xsurf[3][m][j] =  E->incr_potential[0][m][j]  
                                   + E->incr_potential[2][m][j] ;

            for (m=1;m<=E->sphere.caps_per_proc;m++)  
            for (j=1;j<=E->lmesh.nsf;j++)  { 
                /*// for writing out coordinates:
                i=j*E->lmesh.noz;
                E->Xsurf[1][m][j] = E->SX[E->mesh.levmax][m][1][i];
                E->Xsurf[2][m][j] = E->SX[E->mesh.levmax][m][2][i];
                E->Xsurf[3][m][j] = E->SX[E->mesh.levmax][m][3][i]; */
                /* output oceanloads for debugging
                   fprintf(fp,"%.4e %.4e %.4e %.4e %.4e %.4e\n",
                   E->slice_ve.surf[3][m][j],       // total topography
                   E->slice_ve.surf[1][m][j],       // incr topo
                   E->init_potential[0][m][j],   // total potential
                   E->incr_potential[0][m][j],   // incr potential
                   E->slice_ve.total_static_oceanload[m][j]  // oceanload
                   /E->ve_data_cont.ice_stress_scale,        // (nondim height)
                   E->slice_ve.total_dynamic_oceanload[m][j] //   
                   /E->ve_data_cont.ice_stress_scale         // 
                   ); */
                fprintf(fp,"%.4e %.4e %.4e %.4e\n",
                        E->slice_ve.surf[3][m][j],       // total topography
                        E->slice_ve.surf[1][m][j],       // incr topo
                        E->init_potential[0][m][j],   // total potential
                        E->Xsurf[3][m][j]);           // incr potential
                        //E->incr_potential[0][m][j]);  // incr potential due to loads change only
            }
            fclose(fp);

            sphere_expansion_output(E,1, E->slice_ve.surf[3],
                                         E->sphere.sphc[0], E->sphere.sphs[0],
                                         E->monitor.solution_cycles, "tps");
            sphere_expansion_output(E,1, E->slice_ve.surf[1],
                                         E->sphere.sphc[0],E->sphere.sphs[0],
                                         E->monitor.solution_cycles,"vtps");
            sphere_expansion_output(E,1, E->init_potential[0],
                                         E->sphere.sphc[0],E->sphere.sphs[0],
                                         E->monitor.solution_cycles,"pttl");
            sphere_expansion_output(E,1, E->Xsurf[3],
                                         E->sphere.sphc[0],E->sphere.sphs[0],
                                         E->monitor.solution_cycles,"pttldot");

        }

        /*// write out CMB values:
        if (E->parallel.me_loc[3]==0)  {

            sprintf(outfile,"%s.topo_b.%d.%d",
                             E->control.data_file2,E->parallel.me,ii);
            //sprintf(outfile,"%s.topo_b.%d.%d",
            //                 E->control.data_file,E->parallel.me,ii);
            fp = fopen(outfile,"w");
            fprintf(fp,"%05d %.5e\n",ii,E->monitor.elapsed_time);
            for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (j=1;j<=E->lmesh.nsf;j++)  { 
                    i=(j-1)*E->lmesh.noz+1;
                    E->Xsurf[1][m][j] = E->SX[E->mesh.levmax][m][1][i];
                    E->Xsurf[2][m][j] = E->SX[E->mesh.levmax][m][2][i];
                    E->Xsurf[3][m][j] = E->SX[E->mesh.levmax][m][3][i];
                    fprintf(fp,"%.4e %.4e %.4e %.4e %.4e\n",
                               E->Xsurf[1][m][j],E->Xsurf[2][m][j],
                               E->slice_ve.botm[3][m][j],
                               E->U[m][E->id[m][i].doff[3]],E->potential[m][i]);
                }
            fclose(fp);

            sphere_expansion_output(E,0,E->slice_ve.botm[3],
                                        E->sphere.sphc[0],E->sphere.sphs[0],
                                        E->monitor.solution_cycles,"tpb");

            for (m=1;m<=E->sphere.caps_per_proc;m++)  
                for (j=1;j<=E->lmesh.nsf;j++)  { 
                    i=(j-1)*E->lmesh.noz+1;
                    E->Xsurf[3][m][j] = E->U[m][E->id[m][i].doff[3]];
                }

            sphere_expansion_output(E,0,E->Xsurf[3],
                                     E->sphere.sphc[0],E->sphere.sphs[0],
                                     E->monitor.solution_cycles,"vtpb");
        } */

    } // end if on a recording timestep

    return;
}

/*========================================================= */
/*========================================================= */
void get_temperature_half_space(struct All_variables *E)
 {

 double timea;

 timea = E->monitor.elapsed_time;

 return;
 }

/*========================================================= */
/*========================================================= */

  void add_viscoelasticity(E, evisc)
  struct All_variables *E;
  float **evisc;
  {

  double visc, alpha;
  const int vpts = vpoints[E->mesh.nsd];
  int m,i,j;

for (m=1;m<=E->sphere.caps_per_proc;m++)
  for (i=1;i<=E->lmesh.nel;i++)   {
    visc = 0.0;
    for(j=1;j<=vpts;j++) 
       visc += evisc[m][(i-1)*vpts+j];
    visc = visc/vpts;

    alpha = E->Maxwelltime[m][i]/(2.0*visc)*E->advection.timestep;
    for(j=1;j<=vpts;j++) 
      evisc[m][(i-1)*vpts+j]=E->Maxwelltime[m][i]/(1.0+alpha);

    E->Maxwelltime[m][i] = (1.0-alpha)/(1.0+alpha);
    }


                           /* Maxwelltime is now alpha/(dt+alpha) */
                           /* evisc is now evisc/(dt+alpha) */

  return;
  }

void update_stress_strain(E,ii)
    struct All_variables *E;
    int ii;
{

    void get_rtf_at_vpts();
    void velo_from_element_d();
    void construct_c3x3matrix_el();
    int i,j,k,e,node,snode,m,nel2;
    
    double *SXX[NCS],*SYY[NCS],*SXY[NCS],*SXZ[NCS],*SZY[NCS],*SZZ[NCS];
    double VV[4][9],Szz,Sxx,Syy,Sxy,Sxz,Szy;
    double Vxyz1,Vxyz2,Vxyz3,Vxyz4,Vxyz5,Vxyz6;
    double Sxyz1,Sxyz2,Sxyz3,Sxyz4,Sxyz5,Sxyz6;
    double sinaa,cosaa,ct,el_volume,Visc,a,b,rtf[4][9];
    struct Shape_function GN;
    struct Shape_function_dA dOmega;
    struct Shape_function_dx GNx;
    static struct CC Cc;
    static struct CCX Ccx;

    
    const int dims=E->mesh.nsd,dofs=E->mesh.dof;
    const int vpts=vpoints[dims];
    const int ppts=ppoints[dims];
    const int ends=enodes[dims];
    const int nno=E->lmesh.nno;
    const int lev=E->mesh.levmax;
    const int sphere_key=1;

   double *gnxx,*gnda;



  for(m=1;m<=E->sphere.caps_per_proc;m++)      {

    for(e=1;e<=E->lmesh.nel;e++)  {
      Szz = 0.0;
      Sxx = 0.0;
      Syy = 0.0;
      Sxy = 0.0;
      Sxz = 0.0;
      Szy = 0.0;

      gnxx = E->gNX[m][e].vpt;

      get_rtf_at_vpts(E,m,E->mesh.levmax,e,rtf);

      if ((e-1)%E->lmesh.elz==0)
        construct_c3x3matrix_el(E,e,&Cc,&Ccx,E->mesh.levmax,m,0);

      velo_from_element_d(E,VV,m,e,sphere_key);
	
      for(j=1;j<=vpts;j++)   {
        Sxyz1 = Sxyz2 = Sxyz3 = Sxyz4 = Sxyz5 = Sxyz6 = 0.0;
        sinaa = sin(rtf[1][j]);
        cosaa = cos(rtf[1][j]);
        ct = cosaa/sinaa;
        Visc = E->EVi[m][(e-1)*vpts+j];
        for(i=1;i<=ends;i++)   {
          for(k=1;k<=dims;k++)   {
          
          Sxyz1 += VV[k][i]*rtf[3][j]*
                 (gnxx[GNVXINDEX(0,i,j)]*Cc.vpt[BVINDEX(1,k,i,j)]
                 +E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(1,k,1,i,j)]
                 +E->N.vpt[GNVINDEX(i,j)]*Cc.vpt[BVINDEX(3,k,i,j)]);

          Sxyz2 += VV[k][i]*rtf[3][j]*
                (E->N.vpt[GNVINDEX(i,j)]*Cc.vpt[BVINDEX(1,k,i,j)]*ct
                +E->N.vpt[GNVINDEX(i,j)]*Cc.vpt[BVINDEX(3,k,i,j)]
                +(gnxx[GNVXINDEX(1,i,j)]*Cc.vpt[BVINDEX(2,k,i,j)]
                 +E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(2,k,2,i,j)])/sinaa);

          Sxyz3 += VV[k][i]*gnxx[GNVXINDEX(2,i,j)]*Cc.vpt[BVINDEX(3,k,i,j)];

	  Sxyz4 += VV[k][i]*rtf[3][j]*
                (gnxx[GNVXINDEX(0,i,j)]*Cc.vpt[BVINDEX(2,k,i,j)]
                +E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(2,k,1,i,j)]
                -ct*Cc.vpt[BVINDEX(2,k,i,j)]*E->N.vpt[GNVINDEX(i,j)]
                +(E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(1,k,2,i,j)]
                 +gnxx[GNVXINDEX(1,i,j)]*Cc.vpt[BVINDEX(1,k,i,j)])/sinaa);

	  Sxyz5 += VV[k][i]*rtf[3][j]*
                (gnxx[GNVXINDEX(2,i,j)]*Cc.vpt[BVINDEX(1,k,i,j)]/rtf[3][j]
                +(E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(3,k,1,i,j)]
                 +gnxx[GNVXINDEX(0,i,j)]*Cc.vpt[BVINDEX(3,k,i,j)]
                 -E->N.vpt[GNVINDEX(i,j)]*Cc.vpt[BVINDEX(1,k,i,j)]));

	  Sxyz6 += VV[k][i]*
                (gnxx[GNVXINDEX(2,i,j)]*Cc.vpt[BVINDEX(2,k,i,j)]
                -rtf[3][j]*E->N.vpt[GNVINDEX(i,j)]*Cc.vpt[BVINDEX(2,k,i,j)]
                +rtf[3][j]/sinaa*(E->N.vpt[GNVINDEX(i,j)]*Ccx.vpt[BVXINDEX(3,k,2,i,j)]+gnxx[GNVXINDEX(1,i,j)]*Cc.vpt[BVINDEX(3,k,i,j)]));
          }
        }

        E->Sxx[m][(e-1)*vpts+j]=2.0*Visc*Sxyz1 + E->Maxwelltime[m][e]*E->Sxx[m][(e-1)*vpts+j];
        E->Syy[m][(e-1)*vpts+j]=2.0*Visc*Sxyz2 + E->Maxwelltime[m][e]*E->Syy[m][(e-1)*vpts+j];
        E->Szz[m][(e-1)*vpts+j]=2.0*Visc*Sxyz3 + E->Maxwelltime[m][e]*E->Szz[m][(e-1)*vpts+j];
        E->Sxy[m][(e-1)*vpts+j]=    Visc*Sxyz4 + E->Maxwelltime[m][e]*E->Sxy[m][(e-1)*vpts+j];
        E->Sxz[m][(e-1)*vpts+j]=    Visc*Sxyz5 + E->Maxwelltime[m][e]*E->Sxz[m][(e-1)*vpts+j];
        E->Szy[m][(e-1)*vpts+j]=    Visc*Sxyz6 + E->Maxwelltime[m][e]*E->Szy[m][(e-1)*vpts+j];
        }

      }    /* end for el */
    }     /* end for m */

    return; 
}      

void std2_timestep(E)
     struct All_variables *E;

{
    static int been = 0;
    static int stages = 0;
    static higher_precision init_u,diff_timestep,root3,root2;
    int i,d,n,nel,el,node;

    higher_precision adv_timestep, ts,uc1,uc2,uc3,uc,size,step,VV[4][9];

    const int dims=E->mesh.nsd;
    const int dofs=E->mesh.dof;
    const int nno=E->mesh.nno;
    const int lev=E->mesh.levmax;
    const int ends=enodes[dims];

   been ++;
    if(E->advection.fixed_timestep != 0.0) {
      E->advection.timestep = E->advection.fixed_timestep;
      return;
    }

  E->ve_data_cont.DIRECT=0;    // 1: means updating viscosity/stiffness matrix

 for (i=stages;i<E->ve_data_cont.stages;i++) {
    E->ve_data_cont.stage = i;
    E->advection.timestep = E->ve_data_cont.stages_timestep[i];

    if (i == 0)  
       been = 1;
    else 
       been = E->ve_data_cont.stages_step[i-1]+1;

    if ( E->monitor.solution_cycles < E->ve_data_cont.stages_step[i] )  {
       // neither 1st nor the last step od the stage 
       E->advection.next_timestep = E->ve_data_cont.stages_timestep[i];
       if (E->monitor.solution_cycles==been) {  // the 1st step of the stage
             E->ve_data_cont.DIRECT=1;
             }
       break;
    }
    else if ( E->monitor.solution_cycles == E->ve_data_cont.stages_step[i] )  {
       // before last timestep of current stage
       if ( i == E->ve_data_cont.stages-1 ) // last stage
           E->advection.next_timestep = E->advection.timestep ;
       else 
           E->advection.next_timestep = E->ve_data_cont.stages_timestep[i+1];
       break;
    }
  }
  stages = E->ve_data_cont.stage;

    return;
  }

